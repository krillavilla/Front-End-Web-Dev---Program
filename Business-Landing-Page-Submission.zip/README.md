# BluePeak Consulting - Business Landing Page

A modern, responsive business landing page built with semantic HTML5 and CSS3. This project fulfills all Udacity Front-End Web Development program requirements including accessibility, responsive design, and code quality standards.

## 📁 Project Structure

```
Business-Landing-Page/
├── index.html                  # Home page (in root as required)
├── pages/
│   └── contact.html            # Contact page with form
├── css/
│   ├── global.css              # Shared styles and design system
│   ├── home.css                # Home page specific styles
│   └── contact.css             # Contact page specific styles
├── images/
│   ├── hero.jpg                # Hero section background image
│   ├── about.jpg               # Media section image with caption
│   └── contact-banner.jpg      # Contact page banner (optional)
└── README.md
```

## 🚀 Quick Start

1. **Download placeholder images** and place them in the `images/` folder:
   - `hero.jpg` - Professional team meeting (suggested: https://unsplash.com/photos/ourqouPDuC8)
   - `about.jpg` - Team at work scene (suggested: https://unsplash.com/photos/KE0nC8-58MQ)
   - `contact-banner.jpg` - Abstract banner image (optional)

2. **Open in browser**: Simply open `index.html` in your web browser

3. **Test responsiveness**: Use Chrome DevTools Device Mode to test at 375px, 768px, and 1024px+ widths

## ✅ Rubric Compliance Checklist

### Project Structure ✓
- [x] CSS-only styling (no inline styles or `<style>` tags)
- [x] Three separate CSS files (global, home, contact)
- [x] Organized file structure with pages/ and css/ folders
- [x] All links properly structured with `<a href="">` tags
- [x] Navbar enables navigation between all pages

### Best Practices ✓
- [x] Semantic HTML5 landmarks (`<header>`, `<nav>`, `<main>`, `<section>`, `<footer>`, `<address>`)
- [x] Meaningful `alt` attributes on all images
- [x] Form labels with proper `for`/`id` relationships
- [x] Correct heading hierarchy (one `<h1>` per page, `<h2>` for sections, `<h3>` for subsections)
- [x] `<em>` and `<strong>` used semantically, not for styling

### Design ✓
- [x] Custom navbar and footer on all pages
- [x] Typography styles with 3+ unique properties each (headings, paragraphs, nav links)
- [x] Color palette with 9 distinct hex values
- [x] All required components: Navigation, Hero, Media with caption, Content paragraphs, Form, Repeated cards
- [x] Home page pattern: Navbar → Hero → Info Cards → Media → About → Footer
- [x] Contact page pattern: Navbar → Banner → Contact Details → Form → Footer

### Layout and Responsiveness ✓
- [x] **Flexbox used**: Navbar alignment, hero content stacking, form layout
- [x] **CSS Grid used**: Info cards (1→2→3 columns), footer desktop layout, hero desktop layout with `grid-template-areas`
- [x] Responsive design tested at 375px, 768px, 1024px+
- [x] Media queries with mobile-first approach
- [x] No horizontal scrolling, readable text, proper touch targets (44px minimum)

### Code Quality ✓
- [x] Valid HTML5 document structure with proper DOCTYPE, meta tags, and semantic elements
- [x] W3C HTML and CSS validation ready
- [x] Consistent 2-space indentation
- [x] Lowercase tags and attributes with double quotes
- [x] CSS with proper formatting: semicolons, spacing, declaration per line
- [x] Kebab-case class names, meaningful semantic naming

## 🎨 Design System

**Colors (Hex Values)**:
- Primary: `#2563eb` (buttons, links)
- Primary Dark: `#1d4ed8` (hover states)
- Accent: `#f59e0b` (highlights)
- Text Dark: `#0f172a` (headings)
- Text Medium: `#334155` (body text)
- Background Light: `#f1f5f9` (panels)
- Background Page: `#f8fafc` (main background)
- Border: `#e2e8f0` (card borders)
- Success: `#10b981` (form states)

**Typography**:
- Headings: Poppins (Google Fonts)
- Body Text: Inter (Google Fonts)

**Grid Breakpoints**:
- Mobile: 320-767px (base styles)
- Tablet: 768px+ (2-column cards, inline form fields)
- Desktop: 1024px+ (3-column cards, enhanced spacing)

## 🖼️ Image Requirements

Place these images in the `images/` folder with exact filenames:

1. **hero.jpg** - Professional team meeting or collaboration scene
   - Recommended size: 1600px width
   - Alt text: "Professional team collaborating in a modern office environment"

2. **about.jpg** - Team at work or office environment
   - Recommended size: 800px width  
   - Alt text: "BluePeak team members working together on strategic planning"

3. **contact-banner.jpg** (optional) - Abstract or professional background
   - Recommended size: 1600px width
   - Used as optional banner background

## 📱 Screenshot Checklist for Submission

Capture these screenshots using Chrome DevTools Device Mode:

**Home Page**:
- Desktop (1024px+): Full page showing all sections
- Tablet (768px): 2-column card grid, responsive hero
- Mobile (375px): Stacked layout, no horizontal scroll

**Contact Page**:
- Desktop (1024px+): 4-column contact info, horizontal form
- Tablet (768px): 2-column contact info, inline name/email fields
- Mobile (375px): Stacked form and contact details

## 🔍 Validation

Before submission, validate your code:

1. **HTML Validation**: https://validator.w3.org/
   - Upload `index.html` and `pages/contact.html`
   - Ensure no errors or warnings

2. **CSS Validation**: https://jigsaw.w3.org/css-validator/
   - Upload each CSS file individually
   - Confirm all styles are valid

## 🚀 Customization

To customize for your own brand:

1. Replace "BluePeak Consulting" with your business name in HTML files
2. Update contact information in both HTML files
3. Modify color palette in `css/global.css` `:root` section
4. Replace placeholder images with your own branded images
5. Update meta descriptions and page titles

## ✨ Features Implemented

- **Accessibility**: Semantic HTML, skip links, proper focus styles, sufficient color contrast
- **Performance**: Optimized images, efficient CSS with custom properties
- **SEO**: Meta descriptions, semantic structure, proper heading hierarchy
- **User Experience**: Smooth transitions, hover effects, responsive design
- **Modern CSS**: CSS Grid, Flexbox, custom properties, mobile-first media queries

---

Built with ❤️ following Udacity Front-End Web Development standards.
